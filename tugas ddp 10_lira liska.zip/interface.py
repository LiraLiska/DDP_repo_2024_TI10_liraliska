import aritmetika as oa
import datar_bangun as lbd
import ruang_bangun as lbr

def main():
    while True:
        print("\nselamat datang di kalkulator hitungan,pilih menu yang anda inginkan : ")
        print("1. Operasi Aritmatika")
        print("2. Luas Bangun Datar")
        print("3. Luas Bangun Ruang")
        print("4. Keluar")
        
        pilihan = input("Pilih menu (1-4): ")
        
        
        if pilihan == '1':
            print("\n-- Operasi Aritmatika --")
            a = float(input("Masukkan angka pertama: "))
            b = float(input("Masukkan angka kedua: "))
            print("Hasil Penjumlahan:", oa.penjumlahan(a, b))
            print("Hasil Pengurangan:", oa.pengurangan(a, b))
            print("Hasil Perkalian:", oa.perkalian(a, b))
            print("Hasil Pembagian:", oa.pembagian(a, b))
            print("Hasil Pangkat:", oa.pangkat(a, b))
        
        elif pilihan == '2':
            print("\n-- Luas Bangun Datar --")
            print("1. Persegi")
            print("2. Persegi Panjang")
            print("3. Segitiga")
            print("4. Lingkaran")
            print("5. Trapesium")
            datar = input("Pilih bangun datar (1-5): ")
            if datar == '1':
                sisi = float(input("Masukkan sisi: "))
                print("Luas Persegi:", lbd.luas_persegi(sisi))
            elif datar == '2':
                panjang = float(input("Masukkan panjang: "))
                lebar = float(input("Masukkan lebar: "))
                print("Luas Persegi Panjang:", lbd.luas_persegi_panjang(panjang, lebar))
            elif datar == '3':
                alas = float(input("Masukkan alas: "))
                tinggi = float(input("Masukkan tinggi: "))
                print("Luas Segitiga:", lbd.luas_segitiga(alas, tinggi))
            elif datar == '4':
                jari_jari = float(input("Masukkan jari-jari: "))
                print("Luas Lingkaran:", lbd.luas_lingkaran(jari_jari))
            elif datar == '5':
                sisi_atas = float(input("Masukkan sisi atas: "))
                sisi_bawah = float(input("Masukkan sisi bawah: "))
                tinggi = float(input("Masukkan tinggi: "))
                print("Luas Trapesium:", lbd.luas_trapesium(sisi_atas, sisi_bawah, tinggi))
        
        elif pilihan == '3':
            print("\n-- Luas Bangun Ruang --")
            print("1. Kubus")
            print("2. Balok")
            print("3. Bola")
            print("4. Tabung")
            print("5. Kerucut")
            ruang = input("Pilih bangun ruang (1-5): ")
            if ruang == '1':
                sisi = float(input("Masukkan sisi: "))
                print("Luas Kubus:", lbr.luas_kubus(sisi))
            elif ruang == '2':
                panjang = float(input("Masukkan panjang: "))
                lebar = float(input("Masukkan lebar: "))
                tinggi = float(input("Masukkan tinggi: "))
                print("Luas Balok:", lbr.luas_balok(panjang, lebar, tinggi))
            elif ruang == '3':
                jari_jari = float(input("Masukkan jari-jari: "))
                print("Luas Bola:", lbr.luas_bola(jari_jari))
            elif ruang == '4':
                jari_jari = float(input("Masukkan jari-jari: "))
                tinggi = float(input("Masukkan tinggi: "))
                print("Luas Tabung:", lbr.luas_tabung(jari_jari, tinggi))
            elif ruang == '5':
                jari_jari = float(input("Masukkan jari-jari: "))
                sisi_miring = float(input("Masukkan sisi miring: "))
                print("Luas Kerucut:", lbr.luas_kerucut(jari_jari, sisi_miring))
        
        elif pilihan == '4':
            print("Terima kasih telah menggunakan aplikasi!")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

if __name__ == "__main__":
    main()
