import math

def tambah(a, b):
    return a + b

def kurang(a, b):
    return a - b

def kali(a, b):
    return a * b

def bagi(a, b):
    if b != 0:
        return a / b
    else:
        return "Pembagian dengan nol tidak diperbolehkan."

def pangkat(a, b):
    return math.pow(a,b)

