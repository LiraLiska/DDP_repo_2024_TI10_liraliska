from Animal import Animal

class Snake(Animal):
    # Konstruktor Properti
    def __init__(self, nama, makanan, hidup, berkembang_biak, kulit, taring):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.kulit = kulit
        self.taring = taring

    #Method Info
    def info_snake(self):
        super().info_animal
        print("Nama Hewan\t\t: ", self.nama,"\nMakanan\t\t\t: ", self.makanan, "\nHidup\t\t\t: ", self.hidup, "\nBerkembang Biak\t\t: ", self.berkembang_biak, "\nKulit\t\t\t: ", self.kulit, "\nJenis Taring\t\t: ", self.taring)
# #Objek
        print()
Snake = Snake("piton", "Daging", "dihutan", "Menghasilkan Telur", "hitam emas", "runcing dan berbisa" )
print()
Snake.info_snake()



