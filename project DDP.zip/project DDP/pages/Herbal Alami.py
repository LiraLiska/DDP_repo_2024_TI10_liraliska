import streamlit as st
import pandas as pd
from PIL import Image 
import base64



class HealthCurrencyConverter:
    def __init__(self):
        # Harga Herbal di Indonesia (IDR)
        self.drug_prices = {
            "": 0,
            "Ginseng": 30000,  
            "Temulawak": 20000,
            "Pepermint": 50000,       
        }

    def calculate_cost_in_idr(self, drug, quantity):
        """
        Menghitung total biaya herbal dalam IDR.

        Args:
            drug (str): Nama herbal.
            quantity (int): Jumlah herbal yang dibeli.

        Returns:
            float: Total biaya herbal dalam IDR.
        """
        if drug not in self.drug_prices:
            return "Herbal tidak ditemukan"
        
        # Harga per unit dalam IDR
        price_per_unit = self.drug_prices[drug]

        # Total biaya
        total_cost = price_per_unit * quantity
        return total_cost

    def add_background(self, image_path):
        """
        Menambahkan gambar latar belakang ke aplikasi.

        Args:
            image_path (str): Path gambar latar belakang.
        """
        st.markdown(
            f"""
            <style>
            .stApp {{
                background-image: url(data:image/jpg;base64,{self._load_image(image_path)});
                background-size: cover;
            }}
            </style>
            """,
            unsafe_allow_html=True,
        )

    def _load_image(self, image_path):
        """
        Memuat gambar dan mengembalikan base64 encoding.

        Args:
            image_path (str): Path gambar.

        Returns:
            str: Base64 encoded string dari gambar.
        """
        with open(image_path, "rb") as file:
            data = file.read()
        return base64.b64encode(data).decode()

    def calculate_drug_cost(self):
        """
        Fungsi utama untuk menjalankan aplikasi.
        """
        # Menambahkan latar belakang
        self.add_background("333.jpg")  # Sesuaikan dengan path gambar yang Anda miliki
        st.title("🌿 Kalkulator Biaya Herbal Alami")
        st.write("Hitung total biaya herbal yang Anda beli dalam mata uang IDR.")

        # Input dari pengguna
        drug = st.selectbox("🍀Pilih Herbal:", list(self.drug_prices.keys()))
        quantity = st.number_input("🍃Jumlah Herbal:", min_value=1, step=1)

        # Tombol untuk menghitung biaya
        if st.button("💲Hitung Biaya"):
            total_cost = self.calculate_cost_in_idr(drug, quantity)
            if isinstance(total_cost, str):
                st.error(total_cost)
            else:
                st.success(f"Total biaya Herbal: {total_cost:.2f} IDR")


# Menjalankan aplikasi Streamlit
if __name__ == "__main__":
    # Inisialisasi kelas dan jalankan aplikasi
    app = HealthCurrencyConverter()
    app.calculate_drug_cost()