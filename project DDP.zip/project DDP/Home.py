import streamlit as st
from datetime import datetime, timedelta
import pandas as pd
import requests
import base64
import altair as alt
import time  # Dipindahkan ke bagian atas

# Tambahkan CSS Kustom
def add_custom_css():
    st.markdown(
        """
        <style>
        .stButton > button {
            color: white;
            background-color: #429E9D;
            border: None;
            border-radius: 10px;
        }
        .stSidebar {
            background-color: #429E9D;
            color: black;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

# Inisialisasi data aktivitas fisik
if "activity_log" not in st.session_state:
    st.session_state.activity_log = []

# Inisialisasi waktu pengingat
if "next_reminder" not in st.session_state:
    st.session_state.next_reminder = None

class HealthApp:

    def add_background(self, image_path: str):
        try:
            with open(image_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode()

            st.markdown(
                f"""
                <style>
                .stApp {{
                    background-image: url("data:image/png;base64,{encoded_string}");
                    background-size: cover;
                }}
                </style>
                """,
                unsafe_allow_html=True,
            )
        except FileNotFoundError:
            st.error(f"Gambar latar '{image_path}' tidak ditemukan.")

    def calculate_bmi(self):
        self.add_background("111.webp")

        # Tambahkan CSS khusus untuk mengubah warna teks menjadi putih
        st.markdown(
    """
    <style>
    .stApp {
        color: white; /* Warna teks utama */
    }
    h1, h2, h3, h4, h5, h6 {
        color: white; /* Warna heading */
    }
    label {
        color: black; /* Warna label */
    }
    input, textarea {
        color: black !important; /* Warna teks input */
        background-color: transparent !important; /* Buat latar belakang input transparan */
    }
    input::placeholder, textarea::placeholder {
        color: black; /* Warna placeholder */
        opacity: 0.8; /* Transparansi placeholder */
    }
    </style>
    """,
    unsafe_allow_html=True,
)
        st.title("📊 Kalkulator BMI")
        st.markdown("#### Mengukur Indeks Massa Tubuh Anda")
        st.write("💡 BMI adalah indikator standar untuk mengevaluasi berat badan Anda.")

        weight = st.number_input(
            "⚖ Masukkan berat badan Anda (kg):",
            min_value=10.0,
            max_value=300.0,
            step=0.1,
        )

        height = st.number_input(
            "📏 Masukkan tinggi badan Anda (m):",
            min_value=0.5,
            max_value=2.5,
            step=0.01,
        )

        if st.button("Hitung BMI 🚀"):
            if weight > 0 and height > 0:
                bmi = weight / (height**2)
                st.write(f"💬 BMI Anda adalah: {bmi:.2f}")
                if bmi < 18.5:
                    st.warning("🔶 Anda berada di bawah berat badan normal.")
                elif 18.5 <= bmi < 24.9:
                    st.success("✔ Anda memiliki berat badan normal.")
                elif 25 <= bmi < 29.9:
                    st.warning("⚠ Anda mengalami kelebihan berat badan.")
                else:
                    st.error("❌ Anda mengalami obesitas.")
            else:
                st.error("❗ Masukkan berat dan tinggi badan yang valid!")
        st.info(
            "🌟 Tips: BMI adalah alat sederhana untuk memantau berat badan, namun konsultasikan dengan ahli gizi untuk evaluasi yang lebih komprehensif."
        )
    def water_reminder(self):
        self.add_background("bbb.jpg")
        st.title("💧 Pengingat Minum Air")
        st.write("🔔 Atur pengingat minum air untuk menjaga hidrasi tubuh.")

        interval = st.slider("⏱ Pilih interval waktu untuk pengingat (menit):", 1, 60, 5)
        repeat = st.number_input("🔄 Masukkan jumlah pengingat yang diinginkan:", min_value=1, value=3, step=1)

        if st.button("Mulai Pengingat 🔄"):
            st.success(f"✔ Pengingat diatur setiap {interval} menit sebanyak {repeat} kali.")
            st.session_state.next_reminder = datetime.now()

            st.write("⏰ Jadwal Pengingat:")

            for i in range(repeat):
                next_time = st.session_state.next_reminder + timedelta(minutes=interval * i)
                st.write(f"🔔 Pengingat ke-{i + 1}: {next_time.strftime('%H:%M:%S')}")

            if st.checkbox("Aktifkan simulasi pengingat (Live Timer)"):
                i = 1
                while i <= repeat:
                    current_time = datetime.now()
                    target_time = st.session_state.next_reminder + timedelta(minutes=interval * (i - 1))
                    if current_time >= target_time:
                        st.warning(f"💧 Waktunya minum air! (Pengingat ke-{i})")
                        i += 1
                    time.sleep(1)


    def calculate_calories(self):
        self.add_background("222.jpg")

# Tambahkan CSS khusus untuk mengubah warna teks menjadi putih
        st.markdown(
    """
    <style>
    .stApp {
        color: white; /* Warna teks utama */
    }
    h1, h2, h3, h4, h5, h6 {
        color: white; /* Warna heading */
    }
    label {
        color: black; /* Warna label */
    }
    input, textarea {
        color: black !important; /* Warna teks input */
        background-color: transparent !important; /* Buat latar belakang input transparan */
    }
    input::placeholder, textarea::placeholder {
        color: black; /* Warna placeholder */
        opacity: 0.8; /* Transparansi placeholder */
    }
    </style>
    """,
    unsafe_allow_html=True,
)

        st.title("🔥 Kalkulator Kalori Harian")
        st.write("🔍 Estimasi kebutuhan kalori harian berdasarkan profil dan aktivitas Anda.")

        gender = st.selectbox("🧍 Pilih jenis kelamin Anda:", ["Pria", "Wanita"])
        age = st.number_input("🎂 Masukkan usia Anda:", min_value=0, step=1)
        weight = st.number_input("⚖ Masukkan berat badan Anda (kg):", min_value=0.0, step=0.1)
        height = st.number_input("📏 Masukkan tinggi badan Anda (cm):", min_value=0.0, step=0.1)
        activity_level = st.selectbox(
            "🚴 Pilih level aktivitas Anda:", ["Rendah", "Sedang", "Tinggi"]
        )

        if st.button("Hitung Kebutuhan Kalori ⚡"):
            if weight > 0 and height > 0 and age > 0:
                if gender == "Pria":
                    bmr = 88.36 + (13.4 * weight) + (4.8 * height) - (5.7 * age)
                else:
                    bmr = 447.6 + (9.2 * weight) + (3.1 * height) - (4.3 * age)

                activity_multiplier = {"Rendah": 1.2, "Sedang": 1.55, "Tinggi": 1.725}
                calories = bmr * activity_multiplier[activity_level]

                st.write(f"🔥 *Kebutuhan kalori harian Anda adalah:* {calories:.2f} kalori")
            else:
                st.error("❗ Masukkan data yang valid!")

    def record_activity(self):
        self.add_background("444.jpg")
        st.title("🏃‍♂ Pencatatan Aktivitas Fisik")
        st.write("🗂 Catat aktivitas fisik harian Anda untuk memantau progres.")

        activity = st.text_input("✏ Masukkan jenis aktivitas (misal: berlari, yoga):")
        duration = st.number_input("⏳ Masukkan durasi aktivitas (menit):", min_value=0, step=1)

        if st.button("Simpan Aktivitas ✅"):
            if activity and duration > 0:
                st.session_state.activity_log.append(
                    {"tanggal": datetime.now().strftime("%Y-%m-%d"), "aktivitas": activity, "durasi": duration}
                )
                st.success("✔ Aktivitas berhasil dicatat!")
            else:
                st.error("❗ Masukkan data aktivitas yang valid!")

        st.subheader("📈 Progres Aktivitas Fisik")
        if st.session_state.activity_log:
            df = pd.DataFrame(st.session_state.activity_log)
            df["tanggal"] = pd.to_datetime(df["tanggal"])
            min_date = df["tanggal"].min()
            max_date = df["tanggal"].max()
            selected_date_range = st.date_input("📅 Pilih rentang waktu:", value=[min_date, max_date])

            if len(selected_date_range) == 2:
                start_date, end_date = selected_date_range
                df = df[(df["tanggal"] >= pd.Timestamp(start_date)) & (df["tanggal"] <= pd.Timestamp(end_date))]

            df_grouped = df.groupby("tanggal")["durasi"].sum().reset_index()

            if not df_grouped.empty:
                chart = (
                    alt.Chart(df_grouped)
                    .mark_bar(color="skyblue")
                    .encode(
                        x=alt.X("tanggal:T", title="Tanggal"),
                        y=alt.Y("durasi:Q", title="Durasi (menit)"),
                        tooltip=["tanggal:T", "durasi:Q"]
                    )
                    .properties(title="Progres Aktivitas Fisik", width=700, height=400)
                    .interactive()
                )
                st.altair_chart(chart, use_container_width=True)
            else:
                st.warning("🚫 Tidak ada data aktivitas dalam rentang waktu yang dipilih.")
        else:
            st.info("🔍 Belum ada aktivitas yang dicatat.")


def main():
    add_custom_css()
    app = HealthApp() 
    st.sidebar.title("🏋 Aplikasi Kesehatan Anda")
    menu = st.sidebar.radio(
        "Pilih fitur:",
        [
            "Kalkulator BMI",
            "Pengingat Minum Air",
            "Kalkulator Kalori Harian",
            "Pencatatan Aktivitas Fisik",
        ],
    )

    if menu == "Kalkulator BMI":
        app.calculate_bmi()
    elif menu == "Pengingat Minum Air":
        app.water_reminder()
    elif menu == "Kalkulator Kalori Harian":
        app.calculate_calories()
    elif menu == "Pencatatan Aktivitas Fisik":
        app.record_activity()
    


if __name__ == "__main__":
    main()
