import streamlit as st

st.title("Halaman Dashboard")

# Inisialisasi awal jika st.session_state['total_semua'] belum ada
if 'total_semua' not in st.session_state:
    st.session_state['total_semua'] = []

def total():
    total_nabung = sum(t['Jumlah']
                        for t in st.session_state['total_semua']
                        if t['Tipe'] == 'Menabung')
    return total_nabung

def total_penarikan():
    total_tarik = sum(t['Jumlah']
                      for t in st.session_state['total_semua']
                      if t['Tipe'] == 'Penarikan')
    return total_tarik

# Menghitung total menabung dan total penarikan
total_nabung = total()
total_tarik = total_penarikan()

# Menghitung sisa saldo
sisa_saldo = total_nabung - total_tarik

# Menampilkan informasi
st.metric("Total Menabung Anda", f"Rp.{total_nabung:,}")
st.metric("Total Penarikan Anda", f"Rp.{total_tarik:,}")
st.metric("Sisa Saldo Tabungan Anda", f"Rp.{sisa_saldo:,}")
