#memanggil file gempa dan import semua method/fungsi
from gempa import *

#Membuat objek gempa dengan argumen 
gempa1 = Gempa('banten',1.2)
gempa2 = Gempa('palu',6.1)
gempa3 = Gempa('cianjur',5.6)
gempa4 = Gempa('Jayapura',3.3)
gempa5 = Gempa('Garut',4.0)

#Informasi gempa
print(':: Info Gempa neng Lira::')
print()
gempa1.dampak()

#Informasi gempa
print(':: Info Gempa neng Lira::')
print()
gempa2.dampak()

#Informasi gempa
print(':: Info Gempa neng Lira::')
print()
gempa3.dampak()

#Informasi gempa
print(':: Info Gempa neng Lira::')
print()
gempa4.dampak()

#Informasi gempa
print(':: Info Gempa neng Lira::')
print()
gempa5.dampak()
